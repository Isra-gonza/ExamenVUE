<template>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
 <ul class="navbar-nav mr-auto">
    <li class="nav-item">
      <router-link to="/" class="nav-link">Home</router-link>
    </li>
    <li class="nav-item">
      <router-link to="/empresas" class="nav-link">Empresas </router-link>
    </li>
    <li class="nav-item">
      <router-link to="/about" class="nav-link">Acerca de </router-link>
    </li>
  </ul>
</nav>
</template>

