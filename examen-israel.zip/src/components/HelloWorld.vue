<template>
  <div class="hello">
    <h1>Examen de Israel Gonzálbez Baños</h1>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ut magna nec purus imperdiet posuere. Nam id rhoncus est. Donec vel felis in ligula volutpat viverra id sit amet nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Cras molestie turpis id tempor placerat. Duis tristique sagittis tempor. Suspendisse fermentum sapien elit, in volutpat arcu semper ut.

Donec ut venenatis nisl, sit amet efficitur lacus. Aenean quis metus sit amet urna volutpat suscipit. Nam mattis, massa non laoreet blandit, lorem mauris elementum ligula, ut fringilla enim lorem sit amet sem. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Duis lobortis nunc a tellus lobortis suscipit. Nullam leo sapien, placerat quis consequat id, rhoncus vel lectus. Maecenas pellentesque massa nec massa finibus elementum. Etiam et erat nibh. Sed dapibus lacus magna, ut varius magna egestas luctus.
    </p>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
