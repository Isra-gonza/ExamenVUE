<template>
  <div class="about">
    <h1>Israel Gonzálbez Baños</h1>
  </div>
</template>
