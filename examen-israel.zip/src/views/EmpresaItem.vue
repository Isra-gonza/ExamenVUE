<template>
  <h1> Empresa {{ id }} </h1>
</template>

<script>
export default {
    name: "EmpresaItem",
    props:['id'],
}
</script>

<style>

</style>